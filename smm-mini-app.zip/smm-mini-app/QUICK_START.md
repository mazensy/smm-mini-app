# البدء السريع 🚀

## الخطوات الأساسية

### 1️⃣ فك الضغط
```bash
unzip smm-mini-app.zip
cd smm-mini-app
```

### 2️⃣ تثبيت المكتبات
```bash
npm install
```

### 3️⃣ تشغيل التطبيق محلياً
```bash
npm run dev
```
ثم افتح: `http://localhost:5173`

### 4️⃣ بناء للإنتاج
```bash
npm run build
```

### 5️⃣ النشر على GitHub Pages
اتبع التعليمات في ملف `GITHUB_PAGES_SETUP.md`

---

## الملفات المهمة 📁

| الملف | الوصف |
|------|--------|
| `src/App.jsx` | التطبيق الرئيسي |
| `src/pages/` | صفحات التطبيق |
| `src/App.css` | الأنماط الرئيسية |
| `vite.config.js` | إعدادات البناء |
| `tailwind.config.js` | إعدادات Tailwind |

---

## الصفحات المتاحة 📄

- **الرئيسية** (Home): عرض الإحصائيات والمعلومات الأساسية
- **الخدمات** (Services): تصفح وتصفية الخدمات المتاحة
- **الطلبات** (Orders): تتبع حالة الطلبات
- **المحفظة** (Wallet): إدارة الرصيد والشحن
- **الملف الشخصي** (Profile): تعديل البيانات الشخصية والأمان

---

## الميزات الحالية ✨

✅ واجهة احترافية وحديثة
✅ دعم كامل للغة العربية (RTL)
✅ تصميم متجاوب (Responsive)
✅ نظام ألوان متناسق
✅ أيقونات من Lucide React
✅ تنقل سلس بين الصفحات
✅ بيانات وهمية للاختبار

---

## التخصيص 🎨

### تغيير الألوان
عدّل الملف `tailwind.config.js`:
```javascript
colors: {
  primary: '#3B82F6',      // اللون الأساسي
  secondary: '#1E40AF',    // اللون الثانوي
  accent: '#F59E0B',       // لون التركيز
  // ...
}
```

### تغيير الخطوط
عدّل `src/index.css`:
```css
body {
  font-family: 'Your Font', sans-serif;
}
```

---

## الاتصال بـ API 🔌

لربط التطبيق بـ API الحقيقي:

1. أنشئ ملف `src/lib/api.js`:
```javascript
import axios from 'axios'

const API = axios.create({
  baseURL: 'https://your-api.com/api'
})

export const getServices = () => API.get('/services')
export const createOrder = (data) => API.post('/orders', data)
// ...
```

2. استخدمه في الصفحات:
```javascript
import { getServices } from '@/lib/api'

useEffect(() => {
  getServices().then(res => setServices(res.data))
}, [])
```

---

## المشاكل الشائعة 🐛

### المشكلة: `npm install` لا يعمل
**الحل**: تأكد من تثبيت Node.js 16+
```bash
node --version
```

### المشكلة: الخادم لا يبدأ
**الحل**: تأكد من أن المنفذ 5173 متاح
```bash
npm run dev -- --port 3000
```

### المشكلة: الأنماط لا تظهر
**الحل**: امسح ذاكرة التخزين المؤقتة
```bash
rm -rf node_modules/.vite
npm run dev
```

---

## الدعم والمساعدة 💬

- 📖 اقرأ `README.md` للمزيد من المعلومات
- 📋 اتبع `GITHUB_PAGES_SETUP.md` للنشر
- 🐛 أبلغ عن الأخطاء على GitHub Issues

---

**استمتع ببناء تطبيقك! 🎉**
