# Flarex - تطبيق الخدمات الذكي 🔥

تطبيق مصغر لتلغرام (Telegram Mini App) متكامل لمنصة خدمات SMM احترافية.

## المميزات الرئيسية ✨

- **تصفح الخدمات**: أكثر من 250 خدمة SMM متنوعة
- **إدارة الطلبات**: تتبع حالة الطلبات في الوقت الفعلي
- **المحفظة الذكية**: شحن الرصيد بطرق دفع متعددة
- **الملف الشخصي**: إدارة البيانات الشخصية والأمان
- **واجهة احترافية**: تصميم عصري وسهل الاستخدام
- **دعم RTL**: دعم كامل للغة العربية

## المتطلبات 📋

- Node.js 16+
- npm أو yarn أو pnpm

## التثبيت والتشغيل 🚀

### 1. استنساخ المشروع
```bash
git clone https://github.com/yourusername/smm-mini-app.git
cd smm-mini-app
```

### 2. تثبيت المكتبات
```bash
npm install
# أو
yarn install
# أو
pnpm install
```

### 3. تشغيل خادم التطوير
```bash
npm run dev
# أو
yarn dev
# أو
pnpm dev
```

سيتم فتح التطبيق على `http://localhost:5173`

### 4. بناء للإنتاج
```bash
npm run build
# أو
yarn build
# أو
pnpm build
```

سيتم إنشاء مجلد `dist` يحتوي على الملفات الجاهزة للنشر.

## النشر على GitHub Pages 📤

### 1. إنشاء مستودع GitHub جديد
اذهب إلى [GitHub](https://github.com/new) وأنشئ مستودع جديد باسم `smm-mini-app`

### 2. ربط المستودع المحلي
```bash
git remote add origin https://github.com/yourusername/smm-mini-app.git
git branch -M main
git push -u origin main
```

### 3. تحديث ملف vite.config.js
أضف السطر التالي في التكوين:
```javascript
export default defineConfig({
  base: '/smm-mini-app/',
  // ... باقي الإعدادات
})
```

### 4. بناء ونشر
```bash
npm run build
git add dist/
git commit -m "Deploy to GitHub Pages"
git push
```

### 5. تفعيل GitHub Pages
- اذهب إلى إعدادات المستودع (Settings)
- اختر Pages من القائمة الجانبية
- اختر `main` و `/dist` كمصدر
- سيتم نشر التطبيق على `https://yourusername.github.io/smm-mini-app/`

## هيكل المشروع 📁

```
smm-mini-app/
├── src/
│   ├── pages/
│   │   ├── Home.jsx
│   │   ├── Services.jsx
│   │   ├── Orders.jsx
│   │   ├── Wallet.jsx
│   │   └── Profile.jsx
│   ├── App.jsx
│   ├── App.css
│   ├── index.css
│   └── main.jsx
├── public/
│   └── images/
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
└── postcss.config.js
```

## التكنولوجيات المستخدمة 🛠️

- **React 18**: مكتبة واجهات المستخدم
- **Vite**: أداة البناء السريعة
- **Tailwind CSS**: إطار عمل CSS
- **Lucide React**: مكتبة الأيقونات
- **Axios**: مكتبة الطلبات HTTP

## الميزات المخطط إضافتها 🔮

- [ ] تكامل مع Telegram Bot API
- [ ] نظام الدفع المتقدم
- [ ] إشعارات فورية
- [ ] نظام التقييمات والتعليقات
- [ ] لوحة تحكم الإدارة
- [ ] تقارير مفصلة

## المساهمة 🤝

نرحب بالمساهمات! يرجى:

1. Fork المشروع
2. إنشاء فرع جديد (`git checkout -b feature/AmazingFeature`)
3. Commit التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. Push إلى الفرع (`git push origin feature/AmazingFeature`)
5. فتح Pull Request

## الترخيص 📄

هذا المشروع مرخص تحت MIT License - انظر ملف [LICENSE](LICENSE) للتفاصيل.

## الدعم 💬

للحصول على الدعم:
- 📧 البريد الإلكتروني: support@flarex.app
- 💬 تلغرام: [@FlarexSupport](https://t.me/FlarexSupport)
- 🐛 الإبلاغ عن الأخطاء: [Issues](https://github.com/yourusername/smm-mini-app/issues)

---

**تم إنشاؤه بـ ❤️ بواسطة فريق Flarex**
