# تعليمات النشر على GitHub Pages 📤

## الخطوة 1: إعداد المستودع على GitHub

### أ. إنشاء مستودع جديد
1. اذهب إلى [GitHub.com](https://github.com)
2. انقر على **+** في الزاوية العلوية اليسرى
3. اختر **New repository**
4. أدخل اسم المستودع: `smm-mini-app`
5. اختر **Public** (عام)
6. انقر **Create repository**

### ب. نسخ رابط المستودع
سيظهر لك رابط المستودع مثل:
```
https://github.com/yourusername/smm-mini-app.git
```

## الخطوة 2: إعداد Git محلياً

### أ. تهيئة Git (إذا لم تكن قد فعلت ذلك)
```bash
cd smm-mini-app
git init
git config user.name "Your Name"
git config user.email "your.email@example.com"
```

### ب. إضافة المستودع البعيد
```bash
git remote add origin https://github.com/yourusername/smm-mini-app.git
```

### ج. إضافة الملفات والـ Commit الأول
```bash
git add .
git commit -m "Initial commit: Flarex Mini App"
git branch -M main
git push -u origin main
```

## الخطوة 3: تحديث vite.config.js

تأكد من أن ملف `vite.config.js` يحتوي على:

```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  base: '/smm-mini-app/',  // ← أضف هذا السطر
  plugins: [react()],
  build: {
    outDir: 'dist',
    assetsDir: 'assets'
  }
})
```

**ملاحظة**: استبدل `smm-mini-app` باسم مستودعك إذا كان مختلفاً.

## الخطوة 4: بناء التطبيق

```bash
npm run build
```

سيتم إنشاء مجلد `dist` يحتوي على الملفات الجاهزة.

## الخطوة 5: نشر على GitHub Pages

### الطريقة الأولى: يدوياً

```bash
# أضف مجلد dist
git add dist/
git commit -m "Build: Deploy to GitHub Pages"
git push origin main
```

### الطريقة الثانية: استخدام GitHub Actions (موصى به)

أنشئ ملف جديد: `.github/workflows/deploy.yml`

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Build
        run: npm run build
      
      - name: Deploy to GitHub Pages
        uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./dist
```

ثم:
```bash
git add .github/
git commit -m "Add GitHub Actions workflow"
git push origin main
```

## الخطوة 6: تفعيل GitHub Pages

1. اذهب إلى مستودعك على GitHub
2. انقر على **Settings** (الإعدادات)
3. اختر **Pages** من القائمة الجانبية
4. تحت **Source**، اختر:
   - Branch: `main`
   - Folder: `/` (الجذر)
5. انقر **Save**

## الخطوة 7: الوصول إلى التطبيق

بعد دقائق قليلة، سيكون التطبيق متاحاً على:
```
https://yourusername.github.io/smm-mini-app/
```

## تحديث التطبيق

في كل مرة تريد تحديث التطبيق:

```bash
# قم بالتغييرات المطلوبة
# ثم:

npm run build
git add .
git commit -m "Update: Description of changes"
git push origin main
```

سيتم تحديث التطبيق تلقائياً!

## استكشاف الأخطاء

### المشكلة: الصفحة لا تظهر بشكل صحيح
**الحل**: تأكد من أن `base` في `vite.config.js` صحيح

### المشكلة: الصور لا تظهر
**الحل**: استخدم المسارات النسبية بدلاً من المطلقة:
```javascript
// ❌ خطأ
<img src="/images/logo.png" />

// ✅ صحيح
<img src="./images/logo.png" />
```

### المشكلة: الأنماط CSS لا تطبق
**الحل**: تأكد من أن ملف `index.css` مستورد في `main.jsx`

## نصائح مهمة 💡

1. **استخدم GitHub Desktop** إذا كنت جديداً على Git
2. **قم بـ Commit بانتظام** بدلاً من رفع كل شيء مرة واحدة
3. **اكتب رسائل Commit واضحة** تصف التغييرات
4. **اختبر التطبيق محلياً** قبل الدفع
5. **استخدم Branches** للميزات الجديدة

## موارد إضافية

- [GitHub Pages Documentation](https://docs.github.com/en/pages)
- [Git Tutorial](https://git-scm.com/doc)
- [Vite Documentation](https://vitejs.dev/)
- [React Documentation](https://react.dev/)

---

**تم إنشاؤه بـ ❤️ لمساعدتك على النشر بسهولة**
