import { useState } from 'react'
import { User, Lock, Bell, Shield, LogOut, Edit2, Save } from 'lucide-react'

export default function Profile({ user, setUser }) {
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || 'user@example.com',
    phone: user?.phone || '+963 123 456 789',
    password: '',
    newPassword: '',
    confirmPassword: ''
  })

  const [notifications, setNotifications] = useState({
    orderUpdates: true,
    promotions: false,
    securityAlerts: true
  })

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSaveProfile = () => {
    if (formData.newPassword && formData.newPassword !== formData.confirmPassword) {
      alert('كلمات المرور غير متطابقة')
      return
    }
    setUser(prev => ({
      ...prev,
      name: formData.name,
      email: formData.email,
      phone: formData.phone
    }))
    setIsEditing(false)
    alert('تم حفظ التغييرات بنجاح')
  }

  const handleNotificationChange = (key) => {
    setNotifications(prev => ({ ...prev, [key]: !prev[key] }))
  }

  return (
    <div className="p-4 md:p-8 space-y-6 animate-fade-in max-w-2xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">الملف الشخصي</h1>
        <p className="text-gray-600">إدارة معلومات حسابك والإعدادات</p>
      </div>

      {/* Profile Card */}
      <div className="card p-8 text-center">
        <div className="w-24 h-24 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center text-white font-bold text-4xl mx-auto mb-4">
          {user?.name?.charAt(0) || 'A'}
        </div>
        <h2 className="text-2xl font-bold text-gray-900">{user?.name}</h2>
        <div className="flex items-center justify-center gap-2 mt-2">
          <Shield className="text-green-600" size={18} />
          <span className="text-green-600 font-semibold">✓ حساب موثق</span>
        </div>
        <p className="text-gray-600 mt-4">معرف المستخدم: {user?.id}</p>
      </div>

      {/* Personal Information */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <User className="text-primary" size={24} />
            <h3 className="text-xl font-bold text-gray-900">المعلومات الشخصية</h3>
          </div>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center gap-2 text-primary hover:text-secondary transition-colors"
          >
            {isEditing ? <Save size={20} /> : <Edit2 size={20} />}
            <span className="text-sm font-semibold">{isEditing ? 'حفظ' : 'تعديل'}</span>
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">الاسم الكامل</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              disabled={!isEditing}
              className={`input-field ${!isEditing && 'bg-gray-50 cursor-not-allowed'}`}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">البريد الإلكتروني</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                disabled={!isEditing}
                className={`input-field ${!isEditing && 'bg-gray-50 cursor-not-allowed'}`}
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">رقم الهاتف</label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                disabled={!isEditing}
                className={`input-field ${!isEditing && 'bg-gray-50 cursor-not-allowed'}`}
              />
            </div>
          </div>

          {isEditing && (
            <div className="pt-4 border-t">
              <h4 className="font-semibold text-gray-900 mb-4">تغيير كلمة المرور</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">كلمة المرور الحالية</label>
                  <input
                    type="password"
                    name="password"
                    placeholder="أدخل كلمة المرور الحالية"
                    value={formData.password}
                    onChange={handleInputChange}
                    className="input-field"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-2">كلمة المرور الجديدة</label>
                    <input
                      type="password"
                      name="newPassword"
                      placeholder="أدخل كلمة المرور الجديدة"
                      value={formData.newPassword}
                      onChange={handleInputChange}
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-2">تأكيد كلمة المرور</label>
                    <input
                      type="password"
                      name="confirmPassword"
                      placeholder="أعد إدخال كلمة المرور"
                      value={formData.confirmPassword}
                      onChange={handleInputChange}
                      className="input-field"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {isEditing && (
            <div className="flex gap-2 pt-4">
              <button onClick={handleSaveProfile} className="flex-1 btn btn-primary">
                حفظ التغييرات
              </button>
              <button onClick={() => setIsEditing(false)} className="flex-1 btn btn-secondary">
                إلغاء
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Security */}
      <div className="card p-6">
        <div className="flex items-center gap-2 mb-6">
          <Lock className="text-primary" size={24} />
          <h3 className="text-xl font-bold text-gray-900">الأمان</h3>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
            <div>
              <p className="font-semibold text-gray-900">التحقق الثنائي</p>
              <p className="text-sm text-gray-600">تفعيل التحقق الثنائي لأمان أكبر</p>
            </div>
            <button className="btn btn-success text-sm">تفعيل</button>
          </div>

          <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div>
              <p className="font-semibold text-gray-900">جلسات نشطة</p>
              <p className="text-sm text-gray-600">إدارة الأجهزة المتصلة بحسابك</p>
            </div>
            <button className="btn btn-secondary text-sm">عرض</button>
          </div>

          <div className="flex items-center justify-between p-4 bg-yellow-50 rounded-lg border border-yellow-200">
            <div>
              <p className="font-semibold text-gray-900">سجل الأنشطة</p>
              <p className="text-sm text-gray-600">عرض سجل تسجيلات الدخول والأنشطة</p>
            </div>
            <button className="btn btn-secondary text-sm">عرض</button>
          </div>
        </div>
      </div>

      {/* Notifications */}
      <div className="card p-6">
        <div className="flex items-center gap-2 mb-6">
          <Bell className="text-primary" size={24} />
          <h3 className="text-xl font-bold text-gray-900">الإشعارات</h3>
        </div>

        <div className="space-y-4">
          {[
            { key: 'orderUpdates', label: 'تحديثات الطلبات', description: 'تلقي إشعارات عند تحديث حالة الطلب' },
            { key: 'promotions', label: 'العروض الترويجية', description: 'تلقي إشعارات بالعروض والخصومات' },
            { key: 'securityAlerts', label: 'تنبيهات الأمان', description: 'تلقي تنبيهات أمان حول حسابك' }
          ].map(item => (
            <div key={item.key} className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <p className="font-semibold text-gray-900">{item.label}</p>
                <p className="text-sm text-gray-600">{item.description}</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifications[item.key]}
                  onChange={() => handleNotificationChange(item.key)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary peer-focus:ring-opacity-50 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Danger Zone */}
      <div className="card p-6 border-2 border-red-200 bg-red-50">
        <h3 className="text-lg font-bold text-red-900 mb-4">منطقة الخطر</h3>
        <div className="space-y-3">
          <button className="w-full btn bg-red-100 text-red-700 hover:bg-red-200 flex items-center justify-center gap-2">
            <LogOut size={18} />
            <span>تسجيل الخروج من جميع الأجهزة</span>
          </button>
          <button className="w-full btn btn-danger flex items-center justify-center gap-2">
            <LogOut size={18} />
            <span>حذف الحساب</span>
          </button>
        </div>
      </div>
    </div>
  )
}
