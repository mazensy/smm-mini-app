import { useState } from 'react'
import { Search, Star, Filter, ShoppingCart } from 'lucide-react'

export default function Services({ user }) {
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')
  const [favorites, setFavorites] = useState([])

  const categories = [
    { id: 'all', name: 'الكل' },
    { id: 'instagram', name: 'إنستغرام' },
    { id: 'tiktok', name: 'تيك توك' },
    { id: 'youtube', name: 'يوتيوب' },
    { id: 'twitter', name: 'تويتر' },
    { id: 'facebook', name: 'فيسبوك' }
  ]

  const services = [
    { id: 1, name: 'متابعين إنستغرام حقيقيين', category: 'instagram', price: 5.99, min: 100, max: 50000, time: '2-4 ساعات', rating: 4.8 },
    { id: 2, name: 'لايكات إنستغرام', category: 'instagram', price: 2.99, min: 50, max: 10000, time: '1-2 ساعات', rating: 4.9 },
    { id: 3, name: 'تعليقات إنستغرام', category: 'instagram', price: 3.99, min: 20, max: 5000, time: '2-3 ساعات', rating: 4.7 },
    { id: 4, name: 'متابعين تيك توك', category: 'tiktok', price: 4.99, min: 100, max: 100000, time: '1-3 ساعات', rating: 4.9 },
    { id: 5, name: 'مشاهدات تيك توك', category: 'tiktok', price: 1.99, min: 500, max: 1000000, time: '30 دقيقة', rating: 5.0 },
    { id: 6, name: 'مشتركي يوتيوب', category: 'youtube', price: 7.99, min: 100, max: 50000, time: '3-5 ساعات', rating: 4.8 },
    { id: 7, name: 'متابعين تويتر', category: 'twitter', price: 3.99, min: 100, max: 50000, time: '2-4 ساعات', rating: 4.6 },
    { id: 8, name: 'متابعين فيسبوك', category: 'facebook', price: 4.49, min: 100, max: 50000, time: '2-4 ساعات', rating: 4.7 }
  ]

  const filteredServices = services.filter(service => {
    const matchCategory = selectedCategory === 'all' || service.category === selectedCategory
    const matchSearch = service.name.includes(searchTerm) || searchTerm === ''
    return matchCategory && matchSearch
  })

  const toggleFavorite = (id) => {
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(fid => fid !== id) : [...prev, id]
    )
  }

  return (
    <div className="p-4 md:p-8 space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">الخدمات المتاحة</h1>
        <p className="text-gray-600">تصفح واختر من آلاف الخدمات المتنوعة</p>
      </div>

      {/* Search and Filter */}
      <div className="card p-6 space-y-4">
        <div className="relative">
          <Search className="absolute right-3 top-3 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="ابحث عن خدمة..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-field pl-10"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-full font-medium transition-all ${
                selectedCategory === cat.id
                  ? 'bg-primary text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredServices.map(service => (
          <div key={service.id} className="card p-6 hover:shadow-xl transition-all">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="font-bold text-gray-900">{service.name}</h3>
                <p className="text-xs text-gray-500 mt-1">الفئة: {service.category}</p>
              </div>
              <button
                onClick={() => toggleFavorite(service.id)}
                className={`transition-colors ${
                  favorites.includes(service.id)
                    ? 'text-yellow-500'
                    : 'text-gray-300 hover:text-yellow-400'
                }`}
              >
                <Star size={20} fill="currentColor" />
              </button>
            </div>

            <div className="space-y-2 mb-4 pb-4 border-b">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">السعر:</span>
                <span className="font-bold text-primary">${service.price}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">الحد الأدنى:</span>
                <span className="text-gray-900">{service.min}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">الحد الأقصى:</span>
                <span className="text-gray-900">{service.max}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">الوقت:</span>
                <span className="text-gray-900">{service.time}</span>
              </div>
            </div>

            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-1">
                <span className="text-yellow-500">⭐</span>
                <span className="text-sm font-semibold">{service.rating}</span>
              </div>
              <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">متاح</span>
            </div>

            <button className="w-full btn btn-primary flex items-center justify-center gap-2">
              <ShoppingCart size={18} />
              <span>طلب الآن</span>
            </button>
          </div>
        ))}
      </div>

      {filteredServices.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-600 text-lg">لم يتم العثور على خدمات</p>
          <p className="text-gray-500 text-sm mt-2">حاول تغيير معايير البحث</p>
        </div>
      )}
    </div>
  )
}
