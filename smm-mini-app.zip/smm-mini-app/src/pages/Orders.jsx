import { Clock, CheckCircle, AlertCircle, TrendingUp } from 'lucide-react'

export default function Orders({ user }) {
  const orders = [
    {
      id: 'ORD-001',
      service: 'متابعين إنستغرام حقيقيين',
      quantity: 1000,
      cost: 5.99,
      status: 'completed',
      progress: 100,
      date: '2024-01-15',
      link: 'instagram.com/user123'
    },
    {
      id: 'ORD-002',
      service: 'لايكات إنستغرام',
      quantity: 500,
      cost: 2.99,
      status: 'processing',
      progress: 65,
      date: '2024-01-16',
      link: 'instagram.com/user123/post/123'
    },
    {
      id: 'ORD-003',
      service: 'مشاهدات تيك توك',
      quantity: 10000,
      cost: 19.99,
      status: 'pending',
      progress: 0,
      date: '2024-01-17',
      link: 'tiktok.com/@user123/video/123'
    },
    {
      id: 'ORD-004',
      service: 'متابعين تيك توك',
      quantity: 500,
      cost: 4.99,
      status: 'completed',
      progress: 100,
      date: '2024-01-14',
      link: 'tiktok.com/@user123'
    },
    {
      id: 'ORD-005',
      service: 'تعليقات إنستغرام',
      quantity: 100,
      cost: 3.99,
      status: 'failed',
      progress: 0,
      date: '2024-01-13',
      link: 'instagram.com/user123/post/456'
    }
  ]

  const getStatusInfo = (status) => {
    const statusMap = {
      completed: { label: 'مكتمل', color: 'bg-green-100 text-green-700', icon: CheckCircle },
      processing: { label: 'قيد المعالجة', color: 'bg-blue-100 text-blue-700', icon: Clock },
      pending: { label: 'قيد الانتظار', color: 'bg-yellow-100 text-yellow-700', icon: Clock },
      failed: { label: 'فشل', color: 'bg-red-100 text-red-700', icon: AlertCircle }
    }
    return statusMap[status]
  }

  const stats = [
    { label: 'إجمالي الطلبات', value: orders.length, icon: TrendingUp, color: 'text-blue-500' },
    { label: 'المكتملة', value: orders.filter(o => o.status === 'completed').length, icon: CheckCircle, color: 'text-green-500' },
    { label: 'قيد المعالجة', value: orders.filter(o => o.status === 'processing').length, icon: Clock, color: 'text-yellow-500' },
    { label: 'الإجمالي المنفق', value: `$${orders.reduce((sum, o) => sum + o.cost, 0).toFixed(2)}`, icon: TrendingUp, color: 'text-purple-500' }
  ]

  return (
    <div className="p-4 md:p-8 space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">الطلبات</h1>
        <p className="text-gray-600">تتبع جميع طلباتك وحالتها</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, idx) => {
          const Icon = stat.icon
          return (
            <div key={idx} className="card p-4 text-center">
              <Icon className={`${stat.color} mx-auto mb-2`} size={24} />
              <p className="text-xs text-gray-600 mb-1">{stat.label}</p>
              <p className="text-lg font-bold text-gray-900">{stat.value}</p>
            </div>
          )
        })}
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        {orders.map(order => {
          const statusInfo = getStatusInfo(order.status)
          const StatusIcon = statusInfo.icon
          return (
            <div key={order.id} className="card p-6 hover:shadow-lg transition-all">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-bold text-gray-900">{order.service}</h3>
                  <p className="text-sm text-gray-500 mt-1">رقم الطلب: {order.id}</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-sm font-semibold flex items-center gap-1 ${statusInfo.color}`}>
                  <StatusIcon size={16} />
                  {statusInfo.label}
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 pb-4 border-b">
                <div>
                  <p className="text-xs text-gray-600 mb-1">الكمية</p>
                  <p className="font-semibold text-gray-900">{order.quantity}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 mb-1">التكلفة</p>
                  <p className="font-semibold text-primary">${order.cost}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 mb-1">التاريخ</p>
                  <p className="font-semibold text-gray-900">{order.date}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 mb-1">الرابط</p>
                  <p className="font-semibold text-gray-900 truncate text-sm">{order.link}</p>
                </div>
              </div>

              {/* Progress Bar */}
              {order.status !== 'failed' && (
                <div className="mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <p className="text-sm text-gray-600">التقدم</p>
                    <p className="text-sm font-semibold text-gray-900">{order.progress}%</p>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-primary to-secondary h-2 rounded-full transition-all duration-300"
                      style={{ width: `${order.progress}%` }}
                    />
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                <button className="flex-1 btn btn-secondary text-sm">التفاصيل</button>
                {order.status === 'completed' && (
                  <button className="flex-1 btn btn-success text-sm">تحميل الإيصال</button>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
