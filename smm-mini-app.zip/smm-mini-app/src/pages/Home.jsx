import { TrendingUp, Zap, Shield, Clock } from 'lucide-react'

export default function Home({ user }) {
  const stats = [
    { icon: Zap, label: 'الخدمات النشطة', value: '250+', color: 'text-yellow-500' },
    { icon: TrendingUp, label: 'الطلبات المكتملة', value: '1,250', color: 'text-green-500' },
    { icon: Clock, label: 'متوسط الوقت', value: '2 ساعة', color: 'text-blue-500' },
    { icon: Shield, label: 'معدل النجاح', value: '99.8%', color: 'text-purple-500' }
  ]

  const features = [
    {
      title: 'خدمات متنوعة',
      description: 'تصفح أكثر من 250 خدمة SMM متنوعة',
      icon: '🎯'
    },
    {
      title: 'أسعار تنافسية',
      description: 'أفضل الأسعار في السوق مع جودة عالية',
      icon: '💰'
    },
    {
      title: 'دعم 24/7',
      description: 'فريق دعم متاح طوال الوقت لمساعدتك',
      icon: '🤝'
    },
    {
      title: 'تسليم سريع',
      description: 'تسليم الخدمات في أسرع وقت ممكن',
      icon: '⚡'
    }
  ]

  return (
    <div className="p-4 md:p-8 space-y-8 animate-fade-in">
      {/* Welcome Section */}
      <div className="gradient-primary text-white rounded-2xl p-8 shadow-lg">
        <h1 className="text-3xl md:text-4xl font-bold mb-2">مرحباً بك في Flarex! 🔥</h1>
        <p className="text-lg opacity-90">منصة الخدمات الذكية والموثوقة</p>
        <div className="mt-6 flex flex-col md:flex-row gap-4">
          <button className="btn btn-secondary flex-1">ابدأ الآن</button>
          <button className="btn bg-white bg-opacity-20 text-white hover:bg-opacity-30 flex-1">تعرف أكثر</button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, idx) => {
          const Icon = stat.icon
          return (
            <div key={idx} className="card p-6 text-center">
              <Icon className={`${stat.color} mx-auto mb-3`} size={32} />
              <p className="text-gray-600 text-sm mb-1">{stat.label}</p>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            </div>
          )
        })}
      </div>

      {/* Features */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">لماذا تختار Flarex؟</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {features.map((feature, idx) => (
            <div key={idx} className="card p-6 hover:shadow-lg transition-all">
              <div className="text-4xl mb-3">{feature.icon}</div>
              <h3 className="font-bold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-sm text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">الإجراءات السريعة</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="card p-6 text-center hover:bg-primary hover:text-white transition-all group">
            <div className="text-4xl mb-3 group-hover:scale-110 transition-transform">🛍️</div>
            <h3 className="font-bold mb-1">تصفح الخدمات</h3>
            <p className="text-sm text-gray-600 group-hover:text-white group-hover:text-opacity-90">اختر من خدماتنا المتنوعة</p>
          </button>
          <button className="card p-6 text-center hover:bg-green-500 hover:text-white transition-all group">
            <div className="text-4xl mb-3 group-hover:scale-110 transition-transform">💳</div>
            <h3 className="font-bold mb-1">شحن الرصيد</h3>
            <p className="text-sm text-gray-600 group-hover:text-white group-hover:text-opacity-90">أضف أموالاً لحسابك</p>
          </button>
          <button className="card p-6 text-center hover:bg-blue-500 hover:text-white transition-all group">
            <div className="text-4xl mb-3 group-hover:scale-110 transition-transform">📊</div>
            <h3 className="font-bold mb-1">تتبع الطلبات</h3>
            <p className="text-sm text-gray-600 group-hover:text-white group-hover:text-opacity-90">راقب حالة طلباتك</p>
          </button>
        </div>
      </div>

      {/* Info Banner */}
      <div className="bg-blue-50 border-l-4 border-blue-500 p-6 rounded-lg">
        <h3 className="font-bold text-blue-900 mb-2">💡 نصيحة</h3>
        <p className="text-blue-800 text-sm">قم بتعيين كلمة سر آمنة لحسابك وتحديث معلوماتك الشخصية من قسم الملف الشخصي لضمان أمان حسابك.</p>
      </div>
    </div>
  )
}
