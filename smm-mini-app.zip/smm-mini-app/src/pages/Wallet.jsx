import { useState } from 'react'
import { CreditCard, DollarSign, TrendingUp, History } from 'lucide-react'

export default function Wallet({ user }) {
  const [depositAmount, setDepositAmount] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('card')
  const [showDepositForm, setShowDepositForm] = useState(false)

  const transactions = [
    { id: 1, type: 'deposit', amount: 50, method: 'بطاقة ائتمان', date: '2024-01-16', status: 'completed' },
    { id: 2, type: 'order', amount: -5.99, method: 'طلب خدمة', date: '2024-01-15', status: 'completed' },
    { id: 3, type: 'order', amount: -2.99, method: 'طلب خدمة', date: '2024-01-14', status: 'completed' },
    { id: 4, type: 'deposit', amount: 100, method: 'محفظة رقمية', date: '2024-01-13', status: 'completed' },
    { id: 5, type: 'order', amount: -19.99, method: 'طلب خدمة', date: '2024-01-12', status: 'completed' }
  ]

  const paymentMethods = [
    { id: 'card', name: 'بطاقة ائتمان', icon: '💳', min: 1, max: 5000 },
    { id: 'wallet', name: 'محفظة رقمية', icon: '📱', min: 1, max: 10000 },
    { id: 'transfer', name: 'تحويل بنكي', icon: '🏦', min: 50, max: 50000 }
  ]

  const handleDeposit = () => {
    if (depositAmount && parseFloat(depositAmount) > 0) {
      alert(`تم إضافة $${depositAmount} إلى حسابك`)
      setDepositAmount('')
      setShowDepositForm(false)
    }
  }

  const totalSpent = transactions
    .filter(t => t.type === 'order')
    .reduce((sum, t) => sum + Math.abs(t.amount), 0)

  const totalDeposited = transactions
    .filter(t => t.type === 'deposit')
    .reduce((sum, t) => sum + t.amount, 0)

  return (
    <div className="p-4 md:p-8 space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">المحفظة</h1>
        <p className="text-gray-600">إدارة رصيدك والعمليات المالية</p>
      </div>

      {/* Balance Card */}
      <div className="gradient-primary text-white rounded-2xl p-8 shadow-lg">
        <p className="text-sm opacity-90 mb-2">الرصيد الحالي</p>
        <h2 className="text-4xl font-bold mb-6">${user?.balance || 0}</h2>
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <p className="text-sm opacity-75">المنفق</p>
            <p className="text-xl font-semibold">${totalSpent.toFixed(2)}</p>
          </div>
          <div>
            <p className="text-sm opacity-75">المودع</p>
            <p className="text-xl font-semibold">${totalDeposited.toFixed(2)}</p>
          </div>
        </div>
        <button
          onClick={() => setShowDepositForm(!showDepositForm)}
          className="w-full btn bg-white text-primary hover:bg-gray-100"
        >
          شحن الرصيد
        </button>
      </div>

      {/* Deposit Form */}
      {showDepositForm && (
        <div className="card p-6 space-y-4 border-2 border-primary">
          <h3 className="font-bold text-lg text-gray-900">شحن الرصيد</h3>
          
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">طريقة الدفع</label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {paymentMethods.map(method => (
                <button
                  key={method.id}
                  onClick={() => setPaymentMethod(method.id)}
                  className={`p-4 rounded-lg border-2 transition-all text-center ${
                    paymentMethod === method.id
                      ? 'border-primary bg-primary bg-opacity-10'
                      : 'border-gray-200 hover:border-primary'
                  }`}
                >
                  <div className="text-2xl mb-2">{method.icon}</div>
                  <p className="font-semibold text-sm">{method.name}</p>
                  <p className="text-xs text-gray-600 mt-1">${method.min} - ${method.max}</p>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">المبلغ (USD)</label>
            <input
              type="number"
              placeholder="أدخل المبلغ"
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
              className="input-field"
              min="1"
              max="50000"
            />
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
            <p className="text-sm text-blue-800">
              <strong>ملاحظة:</strong> سيتم إضافة المبلغ إلى حسابك فوراً بعد تأكيد الدفع
            </p>
          </div>

          <div className="flex gap-2">
            <button onClick={handleDeposit} className="flex-1 btn btn-primary">
              متابعة الدفع
            </button>
            <button
              onClick={() => setShowDepositForm(false)}
              className="flex-1 btn btn-secondary"
            >
              إلغاء
            </button>
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="card p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <DollarSign className="text-green-600" size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-600">إجمالي المودع</p>
              <p className="text-xl font-bold text-gray-900">${totalDeposited.toFixed(2)}</p>
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="text-red-600" size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-600">إجمالي المنفق</p>
              <p className="text-xl font-bold text-gray-900">${totalSpent.toFixed(2)}</p>
            </div>
          </div>
        </div>

        <div className="card p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <CreditCard className="text-blue-600" size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-600">عدد العمليات</p>
              <p className="text-xl font-bold text-gray-900">{transactions.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Transaction History */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <History size={24} className="text-primary" />
          <h3 className="text-xl font-bold text-gray-900">سجل العمليات</h3>
        </div>

        <div className="space-y-3">
          {transactions.map(transaction => (
            <div key={transaction.id} className="card p-4 flex items-center justify-between hover:shadow-md transition-all">
              <div className="flex items-center gap-4 flex-1">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                  transaction.type === 'deposit'
                    ? 'bg-green-100 text-green-600'
                    : 'bg-red-100 text-red-600'
                }`}>
                  {transaction.type === 'deposit' ? '📥' : '📤'}
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900">{transaction.method}</p>
                  <p className="text-sm text-gray-500">{transaction.date}</p>
                </div>
              </div>
              <div className="text-right">
                <p className={`font-bold text-lg ${
                  transaction.type === 'deposit'
                    ? 'text-green-600'
                    : 'text-red-600'
                }`}>
                  {transaction.type === 'deposit' ? '+' : ''}{transaction.amount}$
                </p>
                <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                  {transaction.status === 'completed' ? '✓ مكتمل' : 'قيد الانتظار'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
