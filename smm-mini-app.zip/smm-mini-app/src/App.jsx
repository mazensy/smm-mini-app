import { useState, useEffect } from 'react'
import { Menu, X, Home, ShoppingBag, Wallet, Settings, LogOut, User } from 'lucide-react'
import Home from './pages/Home'
import Services from './pages/Services'
import Orders from './pages/Orders'
import Wallet from './pages/Wallet'
import Profile from './pages/Profile'
import './App.css'

export default function App() {
  const [currentPage, setCurrentPage] = useState('home')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [user, setUser] = useState(null)

  useEffect(() => {
    // محاكاة بيانات المستخدم من Telegram
    const mockUser = {
      id: 123456,
      name: 'أحمد محمد',
      balance: 150.50,
      currency: 'USD',
      verified: true
    }
    setUser(mockUser)
  }, [])

  const pages = {
    home: <Home user={user} />,
    services: <Services user={user} />,
    orders: <Orders user={user} />,
    wallet: <Wallet user={user} />,
    profile: <Profile user={user} setUser={setUser} />
  }

  const navItems = [
    { id: 'home', label: 'الرئيسية', icon: Home },
    { id: 'services', label: 'الخدمات', icon: ShoppingBag },
    { id: 'orders', label: 'الطلبات', icon: Menu },
    { id: 'wallet', label: 'المحفظة', icon: Wallet },
    { id: 'profile', label: 'الملف الشخصي', icon: User }
  ]

  return (
    <div className="flex h-screen bg-gray-50 rtl">
      {/* Sidebar */}
      <div className={`fixed inset-y-0 right-0 z-40 w-64 bg-white shadow-lg transform transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : 'translate-x-full'} md:relative md:translate-x-0`}>
        <div className="p-6 border-b">
          <h1 className="text-2xl font-bold text-primary">🔥 Flarex</h1>
          <p className="text-sm text-gray-600 mt-1">تطبيق الخدمات الذكي</p>
        </div>
        
        <nav className="p-4 space-y-2">
          {navItems.map(item => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentPage(item.id)
                  setSidebarOpen(false)
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  currentPage === item.id
                    ? 'bg-primary text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Icon size={20} />
                <span>{item.label}</span>
              </button>
            )
          })}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t">
          <button className="w-full flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
            <LogOut size={20} />
            <span>تسجيل الخروج</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm border-b sticky top-0 z-30">
          <div className="flex items-center justify-between px-4 py-4 md:px-6">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="md:hidden text-gray-700 hover:text-primary"
            >
              {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            
            <div className="flex items-center gap-4">
              {user && (
                <>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-gray-900">{user.name}</p>
                    <p className="text-xs text-gray-500">الرصيد: ${user.balance}</p>
                  </div>
                  <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center text-white font-bold">
                    {user.name.charAt(0)}
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto">
          {pages[currentPage]}
        </main>
      </div>

      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  )
}
